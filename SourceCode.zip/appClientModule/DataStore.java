import java.io.IOException;
import java.util.concurrent.ConcurrentMap;
import org.mapdb.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class DataStore {
	private String  Operation;
	private String  keyToken;
	private String	jsonObj;
	private String  dbfilepath;
	private String  logfile;


	//getters
	public String getoperation() {
		return this.Operation;
	}

	public String getKeyValue() {
		return this.keyToken;
	}

	public String getjsonVal() {
		return this.jsonObj;
	}

	public String getdbfilepath() {
		return this.dbfilepath;
	}

	public String getlogfile() {
		return this.logfile;
	}

	// setters
	public void setoperation(String val) {
		this.Operation = val;
	}

	public void setKeyValue(String val) {
		this.keyToken = val;
	}

	public void setjsonVal(String val) {
		this.jsonObj = val;
	}

	public void setdbfilepath(String val) {
		this.dbfilepath = val;
	}

	public void setlogfile(String val) {
		this.logfile = val;
	}


	// default constructor
	public DataStore() {
		String  currPath = System.getProperty("user.dir");

		this.setoperation("R");
		this.setdbfilepath(currPath+"/freshWorks.db");
		this.setlogfile(currPath+"/dataStore.log");
	}

	// Modifying the input json script if not passed well
	public void CorrectInputJsonString() {

		if (this.getjsonVal().charAt(1) != '"') {
			String temp = this.getjsonVal();

			temp = temp.replace(" ", "").replace("{","{\"").replace(":","\":\"").replace(",","\",\"").replace("}","\"}");

			this.setjsonVal(temp);
		} else {
			System.out.println("Assumption: Input json provided was either accurate or not provided");
		}
	}

	// Method to process data
	public JSONObject processFile() throws IOException, DBException, Exception {

		DB db = DBMaker.fileDB(this.getdbfilepath()).make();
		JSONObject jo = new JSONObject();

		// Each line is whitespace separated with key value pair
		try
		{
			char operation = this.getoperation().charAt(0);

			if (operation == 'C' /* Create */) {
				this.processDataCreate(db, this.getKeyValue(), this.getjsonVal());
			}
			else if (operation == 'R' /* Read */) {
				jo = this.processDataRead(db, this.getKeyValue());
			}
			else if (operation == 'D' /* Delete */) {
				this.processDataDelete(db, this.getKeyValue());
			}
		}
		catch (Exception e)
		{
			throw e;
		}
		finally {
			db.close();
		}

		return jo;
	}

	public JSONObject processDataRead(DB db, String keyValue) throws Exception {

		String temp = "";
		ConcurrentMap<String, String> map = db.hashMap("FW").keySerializer(Serializer.STRING).valueSerializer(Serializer.STRING).hashSeed(101).createOrOpen();

		try
		{
			temp = map.get(keyValue);
		}
		catch (NullPointerException e)
		{
			System.out.println("Processing as...NoKeyValueFound");
		}

		if ((temp == null) || (temp == ""))
			temp = "{\"ERROR\": \"ValueNotFound\"}";

		JSONParser parser  = new JSONParser();
		JSONObject jsonObj = (JSONObject) parser.parse(temp);

		return jsonObj;
	}

	public void processDataCreate(DB db, String keyValue, String jsonObj) throws Exception {

		JSONObject jo = new JSONObject();

		jo = this.processDataRead(db, keyValue);

		if (!jo.containsKey("ERROR")) {
			throw new Exception("Key already exists. Cannot Create duplicate.");
		}
		else {

			ConcurrentMap<String, String> map = db.hashMap("FW").keySerializer(Serializer.STRING).valueSerializer(Serializer.STRING).hashSeed(101).createOrOpen();

			map.put(keyValue, jsonObj);

			db.commit();
		}
	}

	public void processDataDelete(DB db, String keyValue) throws Exception {

		JSONObject jo = new JSONObject();

		jo = this.processDataRead(db, keyValue);

		if (jo.containsKey("ERROR")) {
			throw new Exception("Key does not exist. Cannot perform delete.");
		}
		else {

			ConcurrentMap<String, String> map = db.hashMap("FW").keySerializer(Serializer.STRING).valueSerializer(Serializer.STRING).hashSeed(101).createOrOpen();

			map.remove(keyValue);

			db.commit();
		}
	}

} // end of class
