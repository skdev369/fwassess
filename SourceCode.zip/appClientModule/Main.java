import java.io.IOException;
import java.util.logging.Logger;
import org.json.simple.JSONObject;
import java.util.logging.FileHandler;

public class Main {
	public static void main(String[] args) {

		final Logger logger = Logger.getLogger(DataStore.class.getName());

		boolean append   = true;
		JSONObject outputJSON = new JSONObject();

		/* Constructor to initialize default location for data & log files */
		DataStore ds = new DataStore();

		try
		{
			if (args.length > 4) {
				throw new IllegalArgumentException("Supported 4 arguments: 1. C/R/D  2. <key>  3. <value>  4. filepath (optional)");
			}
			else if (args.length < 2) {
				throw new IllegalArgumentException("Minimum 2 arguments needed: 1. R(default)  2. <key>");
			}
			else if (args.length == 4) {
				ds.setoperation(args[0]);
				ds.setKeyValue(args[1]);
				ds.setjsonVal(args[2]);
				ds.setdbfilepath(args[3]+"/freshWorks.db");
			}
			else if (args.length == 3) {
				ds.setoperation(args[0]);
				ds.setKeyValue(args[1]);
				ds.setjsonVal(args[2]);
			}
			else {
				ds.setKeyValue(args[1]);
			}

			// Correct JSON  string if needed
			if (ds.getjsonVal() != null)
				ds.CorrectInputJsonString();

			// Setup logging
			FileHandler handler = new FileHandler(ds.getlogfile(), append);
			logger.addHandler(handler);

			logger.info("Operation: "+ds.getoperation());
			logger.info("Key:       "+ds.getKeyValue());
			logger.info("jsonObj:   "+ds.getjsonVal());
			logger.info("DB path:   "+ds.getdbfilepath());
			logger.info("Log path:  "+ds.getlogfile());

			outputJSON = ds.processFile();

			if (!outputJSON.isEmpty()) {
				System.out.println("Data returned: "+outputJSON.toString());
				logger.info("Return String After read: "+outputJSON.toString());
			}
		}
		catch (IllegalArgumentException e)
		{
			logger.warning(e.getMessage());
		}
		catch (IOException e)
		{
			logger.warning(e.getMessage());
		}
		catch (SecurityException e)
		{
			logger.warning(e.getMessage());
		}
		catch (Exception e)
		{
			logger.severe(e.getMessage());

			//e.printStackTrace();
		}

	} //End of main method

} //End of class